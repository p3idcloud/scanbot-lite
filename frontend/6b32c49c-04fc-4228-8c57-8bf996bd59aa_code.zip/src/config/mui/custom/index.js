import palette from './palette';

export { palette };
