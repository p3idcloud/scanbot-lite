export const authConstants = {
    SESSION_TOKEN: 'next-auth.session-token',
    CALLBACK_URL: 'next-auth.callback-url',
    CSRF_TOKEN: 'next-auth.csrf-token',
    REGISTRATION_TOKEN: 'registrationToken'
}