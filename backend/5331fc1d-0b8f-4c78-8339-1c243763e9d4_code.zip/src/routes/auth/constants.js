const SESSION_TOKEN = 'next-auth.session-token';
const CALLBACK_URL = 'next-auth.callback-url';
const CSRF_TOKEN = 'next-auth.csrf-token';
const REGISTRATION_TOKEN = 'registrationToken';

module.exports = { SESSION_TOKEN, CALLBACK_URL, CSRF_TOKEN, REGISTRATION_TOKEN };