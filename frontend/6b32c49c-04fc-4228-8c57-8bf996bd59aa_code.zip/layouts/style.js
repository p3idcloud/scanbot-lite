import { styled } from "@mui/material";

export const Wrapper = styled('div')(({ theme }) => ({
    minHeight: "100vh"
}));